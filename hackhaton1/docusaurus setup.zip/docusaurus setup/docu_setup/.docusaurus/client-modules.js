export default [
  require("C:\\Users\\AAC\\OneDrive\\Desktop\\docusaurus setup\\docu_setup\\.docusaurus\\docusaurus-plugin-css-cascade-layers\\default\\layers.css"),
  require("C:\\Users\\AAC\\OneDrive\\Desktop\\docusaurus setup\\docu_setup\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\AAC\\OneDrive\\Desktop\\docusaurus setup\\docu_setup\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\AAC\\OneDrive\\Desktop\\docusaurus setup\\docu_setup\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Users\\AAC\\OneDrive\\Desktop\\docusaurus setup\\docu_setup\\src\\css\\custom.css"),
];
